package com.demo.exception;

public class BusinessException extends Exception {

	public BusinessException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BusinessException(final String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
