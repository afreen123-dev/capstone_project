import { Component, OnInit } from '@angular/core';
import { FoodItemService } from '../Fooditem.service';
import { FoodItem } from '../Fooditem';

@Component({
  selector: 'app-delete-fooditem',
  templateUrl: './delete-fooditem.component.html',
  styleUrls: ['./delete-fooditem.component.css']
})
export class DeleteFooditemComponent implements OnInit {

  FooditemIdModel:number;
  Fooditems:FoodItem[]=[];
  FooditemService: any;
  constructor(private kitchenService:FoodItemService) { }

  public deleteFooditemById():void{
    this.FooditemService.deleteFooditemById(this.FooditemIdModel).subscribe( data => {
      this.Fooditems = this.Fooditems.splice(this.FooditemIdModel-1,1);
    })
};
  ngOnInit() {
  }

}
