export class FoodItem {
    id: number;
    name: string;
    cost: number;
    cuisine: string;
    description: string;
    offers: string;
}
