import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { FoodItem } from './FoodItem';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FoodItemService {
  getFooditemByCost(FooditemCost: number) {
    throw new Error("Method not implemented.");
  }
  deleteFooditemById(kitchenIdModel: any) {
    throw new Error("Method not implemented.");
  }
  deleteFoodItem(FoodItem: FoodItem[]) {
    throw new Error("Method not implemented.");
  }
  private url:string;
  constructor(private http:HttpClient) {
    this.url='http://localhost:9200/FoodItem';
   }
   public createFoodItem(FoodItem:FoodItem):Observable<FoodItem>{
    return this.http.post<FoodItem>(this.url,FoodItem);
  }
  public deleteFoodItemById(id:number): Observable<FoodItem> {
    return this.http.get<FoodItem>(this.url + id);
  }
  public getKitchenByCost(cost:number): Observable<FoodItem> {
    return this.http.get<FoodItem>(this.url + cost);
  }
  public getAllKitchens():Observable<FoodItem[]>{
    return this.http.get<FoodItem[]>(this.url+"s");
  }
}
