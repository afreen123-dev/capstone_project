import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateFooditemComponent } from './create-Fooditem/create-Fooditem.component';
import { DeleteFooditemComponent } from './delete-Fooditem/delete-Fooditem.component';
import { SearchFooditemComponent } from './search-Fooditem/search-Fooditem.component';
import { FooditemsListComponent } from './Fooditems-list/Fooditems-list.component';
const routes: Routes = [
  {path:'createFooditem',component:CreateFooditemComponent},
  {path:'deleteFooditem',component:DeleteFooditemComponent},
  {path:'searchFooditem',component:SearchFooditemComponent},
  {path:'FooditemsList',component:FooditemsListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

